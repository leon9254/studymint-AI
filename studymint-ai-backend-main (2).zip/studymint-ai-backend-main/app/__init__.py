"""StudyMint AI backend package."""
